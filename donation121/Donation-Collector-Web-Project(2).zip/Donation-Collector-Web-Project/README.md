# Donation-Collector-Web-Project
This is a website that can help NGO to collect residents' donations
