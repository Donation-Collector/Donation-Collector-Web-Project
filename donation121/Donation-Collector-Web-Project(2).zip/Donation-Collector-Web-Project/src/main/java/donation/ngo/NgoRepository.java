package donation.ngo;

import org.springframework.data.repository.CrudRepository;

public interface NgoRepository extends CrudRepository<Ngo, String>{

}
